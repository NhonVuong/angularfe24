import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap2-header',
  templateUrl: './bai-tap2-header.component.html',
  styleUrls: ['./bai-tap2-header.component.css']
})
export class BaiTap2HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
