import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap2-sidebar',
  templateUrl: './bai-tap2-sidebar.component.html',
  styleUrls: ['./bai-tap2-sidebar.component.css']
})
export class BaiTap2SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
