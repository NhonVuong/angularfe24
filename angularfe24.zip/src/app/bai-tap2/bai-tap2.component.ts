import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap2',
  templateUrl: './bai-tap2.component.html',
  styleUrls: ['./bai-tap2.component.css']
})
export class BaiTap2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
