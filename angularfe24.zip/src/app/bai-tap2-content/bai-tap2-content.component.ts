import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap2-content',
  templateUrl: './bai-tap2-content.component.html',
  styleUrls: ['./bai-tap2-content.component.css']
})
export class BaiTap2ContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
