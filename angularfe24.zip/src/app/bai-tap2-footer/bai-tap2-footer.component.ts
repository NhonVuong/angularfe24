import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap2-footer',
  templateUrl: './bai-tap2-footer.component.html',
  styleUrls: ['./bai-tap2-footer.component.css']
})
export class BaiTap2FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
