import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap',
  templateUrl: './bai-tap.component.html',
  styleUrls: ['./bai-tap.component.css']
})
export class BaiTapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
